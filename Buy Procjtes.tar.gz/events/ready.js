const client = require('..');
var ms = require("ms")
var Discord = require("discord.js");

client.on('ready', () => {
    console.log('Bot is ready!');
    client.user.setStatus("dnd")
    client.user.setActivity({"name":"Eras Services","type":Discord.ActivityType.Playing})
 
});
