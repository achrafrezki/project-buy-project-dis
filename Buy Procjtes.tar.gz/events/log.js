const { EmbedBuilder } = require("discord.js");
const client = require("..");

client.on("logcreate" , async (interaction,data) => {
    const ch =await interaction.guild.channels.cache.get(client.config.channellog)
    const Embed = new EmbedBuilder()
    .setColor("Random")
    .setTimestamp()
    .setThumbnail(interaction.guild.iconURL())
    .setFields({
        name:`Project Name`,
        value:`**${data.name}**`
    },{
        name:`~ Client`,
        value:`**@${interaction.user.username}**`
    })
    .setTitle("تم شراء بروجكت جديد")
    .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
    .setAuthor({
      name: interaction.guild.name,
      iconURL: interaction.guild.iconURL(),
    });
    if(!ch) return;
    ch.send({embeds:[Embed]})
})