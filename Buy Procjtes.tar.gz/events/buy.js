const client = require("..");
const {
    EmbedBuilder,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    StringSelectMenuBuilder,
  } = require("discord.js");
  
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isButton()) return;
  if (interaction.customId == "order") {
    if (client.probot.check(interaction))
    return interaction.reply({
      content: ` you already have an order !`,
      ephemeral: true,
    });


    const Msg = await  interaction.reply({
        content: `Waiting ..`,
        ephemeral: true,
      });
    try {
      const projects = await HandleProjects(client.projects);
     

 

      const Channel = await interaction.guild.channels.create({
        name: `ticket-${interaction.user.username}`,
      });
      const Category = await interaction.guild.channels.cache.get(
        client.config.parent
      );
      await Channel.setParent(Category);
      await Channel.permissionOverwrites.edit(
        interaction.guild.roles.everyone,
        { ViewChannel: false }
      );
      await Channel.permissionOverwrites.edit(interaction.user, {
        ViewChannel: true,
      });
      await Msg.edit({content:`Go ${Channel}`});

      const embed = new EmbedBuilder()
      .setColor("Random")
      .setTimestamp()
      .setThumbnail(interaction.guild.iconURL())
      .setTitle("**متجر البروجكتات**")
      .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
      .setAuthor({
        name: interaction.guild.name,
        iconURL: interaction.guild.iconURL(),
      });

    const back = new ButtonBuilder()
      .setStyle(ButtonStyle.Danger)
      .setLabel("Back")
      .setCustomId(`back_0`)
      .setEmoji("◀️")
      .setDisabled(true);

    const next = new ButtonBuilder()
      .setStyle(ButtonStyle.Primary)
      .setLabel("Next")
      .setCustomId(`next_0`)
      .setEmoji("▶️");


      const deletee = new ButtonBuilder()
      .setStyle(ButtonStyle.Danger)
      .setLabel("Delete")
      .setCustomId(`delete`)

    const select = new StringSelectMenuBuilder()
      .setCustomId("select")
      .setPlaceholder("أختر البروجكت من هنا");

    if (projects.length == 0) {
      next.setDisabled(true);
      next.setStyle(ButtonStyle.Danger);
      select.setDisabled(true);
      select.setOptions({
        label: "17a",
        value: "disabled",
      });
    } else if (projects.length == 1) {
      next.setDisabled(true);
      next.setStyle(ButtonStyle.Danger);
      select.setOptions(
        projects[0].map((m, ind) => {
          return { label: m.name, value: `project_${m.name}_${ind}` };
        })
      );
    } else {
      select.setOptions(
        projects[0].map((m, ind) => {
          return { label: m.name, value: `project_${m.name}_${ind}` };
        })
      );
    }
    const row1 = new ActionRowBuilder().setComponents(select);
    const row = new ActionRowBuilder().setComponents(back, next);
    const row11 = new ActionRowBuilder().setComponents(deletee);
    const Msgg = await Channel.send({
      content: `${interaction.user}`,
      components: [row, row1,row11],
      embeds: [embed],
    });
	
    const colleceter = Channel.createMessageComponentCollector({
      filter: (u) => u.user.id == interaction.user.id,
    });
    colleceter.on("collect", async (interactionn) => {
      if (interactionn.isButton()) {
        if(interactionn.customId == "delete") {
             
             await interactionn.deferUpdate();
            await interactionn.channel.delete();
        }
        if (interactionn.customId.startsWith("next")) {
          var i = +interactionn.customId.split("_")[1];

          i++;
          if (i + 1 == projects.length) {
            next.setStyle(ButtonStyle.Danger);
            next.setDisabled(true);
            back.setDisabled(false);
            back.setStyle(ButtonStyle.Primary);
          }
          select.setOptions(
            projects[i].map((m, ind) => {
              return { label: m.name, value: `project_${m.name}_${ind}` };
            })
          );
          back.setCustomId(`back_${i}`);
            back.setDisabled(false);
          next.setCustomId(`next_${i}`);
          row1.setComponents(select);
          row.setComponents(back, next);
          await interactionn.deferUpdate();
          await Msgg.edit({    components: [row, row1,row11] });
        }
        if (interactionn.customId.startsWith("back")) {
          var i = +interactionn.customId.split("_")[1];
           
         i--
              
          if (i == 0) {
            back.setDisabled(true);
            back.setCustomId(`back_0`);
            back.setStyle(ButtonStyle.Danger);
          }

          
          next.setCustomId(`next_${i}`);
          next.setDisabled(false)
          next.setStyle(ButtonStyle.Primary)
          select.setOptions(
            projects[i].map((m, ind) => {
              return {
                label: m.name,
                value: `project_${m.name}_${5 ** (i == 0 ? 1 : i)}`,
              };
            })
          );
          row.setComponents(back, next);
          row1.setComponents(select);
          await interactionn.deferUpdate();
          await Msgg.edit({    components: [row, row1,row11] });
        }
      }
      if (interactionn.isStringSelectMenu()) {
        if (client.probot.check(interaction))
        return interactionn.channel.send(` you already have an order !`);
        select.setDisabled(true);
        next.setStyle(ButtonStyle.Danger);
        back.setStyle(ButtonStyle.Danger);
        next.setDisabled(true);
        back.setDisabled(true);
        row.setComponents(back, next);
        row1.setComponents(select);
        const value = interactionn.values[0].split("_");
        const projectindex = value[2];
           const name = value[1];
        const project = client.projects.find((m) => m.name == name);
          if(!project)
               return await  Msgg.edit({content:"Cant Find Project"});
        embed.setDescription(`
        قم بالتحويل 
        \`\`\`c ${client.config.bankid} ${project.price}\`\`\`
        `)

        
        await interactionn.deferUpdate()
         await interactionn.channel.send({content:` \`\`\`c ${client.config.bankid} ${project.price}\`\`\``})
        await Msgg.edit({    components: [row, row1,row11],embeds:[embed]});
       
   
    var check = await client.probot.collect(interactionn,interactionn.channel, {
      probotId: client.config.probotid,
      owners: client.config.dev,
      time: 1000 * 60 * 2, // 5 min
      userId: interactionn.user.id, // when you not specify the user, return full collection for first transfer in main channel.
      price: project.price,
      fullPrice: false, // member must send the price with tax
    });
    if (check.status) {
     const em = new  EmbedBuilder()
     .setTitle(project.name)
     .setURL(project.url)
      .setColor("Random")
      await interactionn.user.send({embeds:[em]})
      await interactionn.channel.send({content:`${interaction.user} **Done !**`})
      client.emit("logcreate",interactionn,{name:project.name})
      const role = interactionn.guild.roles.cache.get(client.config.clientrole)
      if(role) {
        await interactionn.member.roles.add(role)
      }
      setTimeout(async () => {
        await Channel.delete()
      },5000)
    } else if (check.error) {
      return interactionn.channel.send(`> ${check.error.message} , ${interactionn.user}`);
    } else {interactionn
      return interactionn.channel.send(`> Required credit: ${check.priceRequired},
      you transfered: ${check.fullPrice}, 
      i got: ${check.priceTransfered},
      retry and transfer ${check.priceTotal}`);
    }

      
      }
    });











    } catch (error) {
      await Msg.edit({ content: `${error.message}`, ephemeral: true });
    }
  }
});

async function HandleProjects(projects) {
  const arr = [];
  var dynamicArray = [];
  for (let i = 0; i < projects.length; i++) {
    const element = projects[i];
    if (i / 5 - 1 < 1 && i <= 4) {
      if (i == 4) {
        dynamicArray.push(element);
        arr[0] = dynamicArray;
        dynamicArray = [];
      } else {
        arr[0] = dynamicArray;
        dynamicArray.push(element);
      }
    } else {
      const Num = i / 5;
      const NumFloored = Math.floor(Num);
      if (dynamicArray.length == 5) {
        arr[NumFloored] = dynamicArray;
        dynamicArray = [];
        dynamicArray.push(element);
      } else {
        arr[NumFloored] = dynamicArray;
        dynamicArray.push(element);
      }
    }
  }
  return arr;
}
