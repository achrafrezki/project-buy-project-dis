module.exports = [
    {
        name:"بروجكت سيستم شوب اسطوري",
        url:"https://cdn.discordapp.com/attachments/1215284726152306709/1244065063774453851/vacc.zip?ex=6660f060&is=665f9ee0&hm=1ebac049bbddd24d71071bcb3412790f2c203dfc26f72097e532d38f71ed5a98&",
        price:30000
    },
    {
        name:"بروجكت نسخ سيرفرات بتوكن مع بانل",
        url:"https://cdn.discordapp.com/attachments/1242485394025480243/1243684693811925184/nskh-yrs.zip?ex=66618861&is=666036e1&hm=914293b8b9f99bda66429d112c306f286b717baf80e978be7dcdc904e72461fe&",
        price:50000
    },
    {
        name:"بروجكت بيع تلفيل حسابات",
        url:"https://cdn.discordapp.com/attachments/1202727262202368040/1203066699126149140/446885b0f582f5e8.zip?ex=66616bec&is=66601a6c&hm=57e295f29d9728cd61294413885dfed2042d83c8ff27e89a00b903663048d14e&",
        price:500000
    },
    {
        name:"بروجكت بيع تثبيت حسابات",
        url:"https://cdn.discordapp.com/attachments/1225534986703212575/1228090571147706438/voicesell.zip?ex=66617db8&is=66602c38&hm=0f8863472b127c5dfb1de318a954c16a91e819150f46ca84ca485037eeca4212&",
        price:500000
    },
    {
        name:"بروجكت بيع حالة playing",
        url:"https://cdn.discordapp.com/attachments/1225534986703212575/1231376812999966770/SellActivity.rar?ex=6660ec06&is=665f9a86&hm=dcffb6cd0824eeaea141fdf0ad3c5c08841dbc3ee7e3e7329a606b94329280f8&",
        price:1300000
    },
    {
        name:"بروجكت بيع حالة اونلاين",
        url:"https://cdn.discordapp.com/attachments/1202727262202368040/1225586643260412017/6bc183ce5d25cda5?ex=6660f382&is=665fa202&hm=00f115dd2a55d829d083cc8d657a5cca8561a789c4070f6dabd766d85d555450&",
        price:1200000
   },
   {
        name:"بروجكت بيع بنرات تلقائي",
        url:"https://cdn.discordapp.com/attachments/1225534986703212575/1231945302500708443/Canvas.zip?ex=66610338&is=665fb1b8&hm=d1905766e04593041704e5fdda443278482f453179072fd79d682437e5f86c42&",
        price:1400000
   },
   {
        name:"بروجكت بيع تلقائي من شغلنا",
        url:"https://cdn.discordapp.com/attachments/1192393249248264242/1225177523760140318/For-AV-MAJED-Auto-sellll.zip?ex=666170bc&is=66601f3c&hm=a391dd69fc8c262e7e2f9cb41f7a54be0db2b623d2ffd4976db9175f7e7fb184&",
        price:500000
  },
  {
        name:"بروجكت بيع شاره المطور",
        url:"https://cdn.discordapp.com/attachments/1225534986703212575/1226760003168505947/DevBadge.zip?ex=666143c8&is=665ff248&hm=e7c9c25434682991cdbce751ef16cfe70cd1bf3f1830300b98c8df0c40526f65&",
        price:1000000
  },
  {

        name:"بروجكت ابتايم قلتش مشفر",
        url:"https://cdn.discordapp.com/attachments/1187720821465153536/1228400424474906684/50d2c60e58a602f9.zip?ex=66614ccb&is=665ffb4b&hm=471dcd2a489e2edb8cb71fd418a60c9e43d0b922c3eae4ed3397e8e5ae2c80ce&",
        price:600000
 },
 {
        name:"بروجكت بيع مونجو ديبي",
        url:"https://cdn.discordapp.com/attachments/1200480858604310538/1226365867135340554/mango.zip?ex=66612637&is=665fd4b7&hm=a67ec1b6c246bcda1d95a2d305b9a950be0ce9fb0dd309842b14d05580500552&",
       price:400000
 },
 {
       name:"بروجكت بيع تشفير اكواد زي حقنا",
       url:"https://cdn.discordapp.com/attachments/1234800351904006196/1234800447609372723/archive-2024-04-30T093445Z.tar.gz?ex=66618308&is=66603188&hm=9c2eb98e8724dcc127b595a7285b514b29306996237a3d567d05be169bcc40f7&",
       price:4000000
 },
 {
      name:"بروجكت بيع تلفيل واونلاين واوتو",
      url:"https://cdn.discordapp.com/attachments/1239696027867418695/1240220757800517773/buy_online-aoto_reaction-leveling.zip?ex=66617496&is=66602316&hm=d88ab393e08bcdd9dd8b6ce571def670e83ef937167344d93fe49b98776cef99&",
      price:1000000
 },
 {
      name:"بروجكت ذكاء اصطناعي انت تحط الداتا",
      url:"https://cdn.discordapp.com/attachments/1174696897924046850/1243555822857097297/majed_ai_bot.zip?ex=6661105c&is=665fbedc&hm=4c95d00f55a0bb6ecd85203329d2f70c128f899f74d66c8f0f3041ad16cf0fec&",
      price:900000
 },
 {
      name:"بروجكت عروض مطور",
      url:"https://cdn.discordapp.com/attachments/1174351152096235602/1210632523407691807/order_v5.zip?ex=666142a6&is=665ff126&hm=dfcda615943247c3f84eb7e71ab2b38de41a6b5a16fd0f924ee769f5ffcb76e7&",
      price:250000
 },
 {
      name:"بروجكت بيع بروجكتات سلاش",
      url:"https://cdn.discordapp.com/attachments/1213189399861399573/1218550536870170635/buy_project.zip?ex=66610fdf&is=665fbe5f&hm=6d943e1b7164cc7d5d760ed87cab347d06bce6fa3f49ebe32d1a5d29d8a8f302&",
      price:500000
 },
 {
      name:"بروجكت بيع توكنات بوتات",
      url:"https://cdn.discordapp.com/attachments/1215543928753885226/1215544124434944150/dada.zip?ex=666154ae&is=6660032e&hm=c6cd6d3ae6a739db9a20d1e13529ce6a8cdfb87a59c6f3c829ff74f34e5265f2&",
      price:150000
 },
 {
      name:"بروجكت برودكاست تحكم",
      url:"https://cdn.discordapp.com/attachments/1174696897924046850/1245389384056832040/Broadcast_Control.zip?ex=6661247f&is=665fd2ff&hm=76f689718736e70691a2e9be1e8c03a33eb43f5b1c03e94c88c5db20124a7c46&",
      price:3000000
 },
 {
      name:"بروجكت رياكشن رول سيليكت مينيو",
      url:"https://cdn.discordapp.com/attachments/1246238685620338803/1246244654509195334/notifications.zip?ex=6660f547&is=665fa3c7&hm=ff94f27abb8f23d7b5074cef7d2b1aaab830d51d9f852e155c6de920969cf1b6&",
      price:400000
 },    
 {
      name:"بروجكت فاتوره",
      url:"https://cdn.discordapp.com/attachments/1174696897924046850/1246949533326381056/faturuhBot.zip?ex=66618b7f&is=666039ff&hm=a01308b4d502b754083de1b88681254f678f6d4f09b7a3ca8b4539549f4bbd26&",
      price:600000
 },
 {
      name:"بروجكت تكت سيليكت مينيو",
      url:"https://cdn.discordapp.com/attachments/1242956284559360051/1242956415249813644/ticket.zip?ex=6661851e&is=6660339e&hm=66d3c996e3d638cb4369519cd2092ffb7ce8fc3430501ae80475b76d349d7648&",
      price:500000
 },
 {
      name:"بروجكت تحميل مقاطع انستا وتيك",
      url:"https://cdn.discordapp.com/attachments/1174696897924046850/1246949533745938572/Social_media_bot.zip?ex=66618b80&is=66603a00&hm=cbab56b36f80cffc6c47be3da2f3ad79c2ee2af4c00852e361de91cb9c43cf58&",
      price:800000
 },
 {
      name:"بروجكت ميكر مطور مع ابتايم ",
      url:"https://cdn.discordapp.com/attachments/1231956822684991539/1240767222712893490/Bot_Maker_Sell_Version.zip?ex=66617746&is=666025c6&hm=285eaa8726620ce5bada6ce552bccaa450e644c5382bd45991861bdf56848a92&",
      price:6000000
 },
 {
      name:"بروجكت سيستم كميونتي 160 امر",
      url:"https://cdn.discordapp.com/attachments/1202727262202368040/1235747079138181200/df54a49d1a85b749.zip?ex=66610026&is=665faea6&hm=f7a4e46b47678b242ada901b7e97a2b30765b8ccc02aa60a7e576a27d8bd8dce&",
      price:1100000
 }, 
 {
      name:"بروجكت بيع نسخ سيرفرات بكوينز مع اشتراكات",
      url:"https://cdn.discordapp.com/attachments/1227407896720052346/1227556431427932232/Alarms.zip?ex=66618684&is=66603504&hm=c0a2fb493dcba30886d0dd1b81e2d316dd19bccd3a91bb8b237cb974f727d424&                                    وقم بوضع هذا الملف بدلاً من ملف subs https://cdn.discordapp.com/attachments/1227407896720052346/1227641585966121012/Subs.js?ex=66612d12&is=665fdb92&hm=4d5b3b8f595ad39311ec868d528bdeda3b7a01d4875779cf9b4feb726237293c&",
      price:900000
 },
    
 {
      name:"بروجكت نسخ سيرفرات بدون بانل",
      url:"https://replit.com/@ce707268e0/cloner",
      price:35000
 },
  
 {
      name:"بروجكت ردود تلقائيه",
      url:"https://replit.com/@ahmeddarkgg158/auto-reply-rdwd-tlqyy?v=1",
      price:12000
 },
  
 {
      name:"بروجكت بيع تلفيل صوتي وكتابي",
      url:"https://cdn.discordapp.com/attachments/1229565096879980584/1247900783115112458/VOICE_TEXT.rar?ex=6661b5ab&is=6660642b&hm=6085931bdaff8417341ac27ac38fee8786ecca3c4d054ce8a712ad54ae9dc370&",
      price:800000
 },
    
 {
      name:"بروجكت طلبات",
      url:"https://replit.com/@kinghsug/Order-Bot?v=1",
      price:15000
 },
    
 {
      name:"بروجكت قيف اواي برفكس",
      url:"https://replit.com/@OnlyMahmouud/Giveaways",
      price:10000
 },
    
 {
      name:"بروجكت استلام تكت",
      url:"https://replit.com/@Motaz-NN/Claim-Tickets-By-EZO?v=1",
      price:8000
 },
    
 {
      name:"بروجكت قيف اواي سلاش",
      url:"https://replit.com/@Ch2mpion/Giveaways-System-Slashs",
      price:10000
 },
    
 {
      name:"بروجكت بيع رومات خاصه",
      url:"https://replit.com/@OnlyMahmouud/Buy-Channels",
      price:25000
 },
    
 {
      name:"بروجكت بيع رتب",
      url:"https://replit.com/@OnlyMahmouud/Roles-Bot",
      price:15000
 },
    
 {
      name:"بروجكت لوقات",
      url:"https://replit.com/@OnlyMahmouud/Logs-Bot",
      price:7000
 },
    
 {
      name:"بروجكت اقتراحات",
      url:"https://replit.com/@OnlyMahmouud/Suggestions-Botv2",
      price:7000
 },
    
 {
      name:"بروجكت حالة ستريمنق للبوتات",
      url:"https://replit.com/@OnlyAhmed1291/Streaming-status",
      price:20000
 },
    
 {
      name:"بروجكت منشن = ميوت",
      url:"https://cdn.discordapp.com/attachments/1174696897924046850/1218928657104637962/MUTE.zip?ex=66611e86&is=665fcd06&hm=23054d8678f832e6f6b7df7421e011316a3b12e457b2a723a640ed3bd7e983d7&",
      price:10000
 },
    
 {
      name:"بروجكت قوانين ازرار",
      url:"https://cdn.discordapp.com/attachments/1174696897924046850/1217602217738244196/MAJED_Bot.zip?ex=6661912e&is=66603fae&hm=bd4401eeaff2dc52ebcac5920db8804f7d0f3a9efd91a66a9f7f390b4e3b6bb2&",
      price:25000
 },
    
 {
      name:"بروجكت قوانين سيليكت مينيو",
      url:"https://replit.com/@Policehshsa/Info-bot",
      price:15000
 },
    
 {
      name:"بروجكت نشر اكواد",
      url:"https://replit.com/@Iaijd7asaneii/Share-Codes",
      price:12000
 },
    
 {
      name:"بروجكت تقديم اداره",
      url:"https://cdn.discordapp.com/attachments/1174696897924046850/1218323336170307684/apply_bot.zip?ex=66618dc6&is=66603c46&hm=7e4a4d3537184d3dccda5bbe3f3c3f8ec20ae3c0d0adc8121dc6c390480e5f15&",
      price:16000
 },
    
 {
      name:"بروجكت ضريبه",
      url:"https://replit.com/@Iaijd7asaneii/Tax-probot-red-Developer-Coding?v=1",
      price:6000
 },
    
 {
      name:"بروجكت فحص روابط",
      url:"https://replit.com/@nothinggmailcom/Check-Urls-Developer-Coding?v=1",
      price:9000
 },
    
 {
      name:"بروجكت ترحيب",
      url:"https://replit.com/@turkishturkish/BoldMotionlessSet",
      price:5000
 },
    
 {
      name:"بروجكت اذكار",
      url:"https://replit.com/@Shuruhatik/mushaf-bot-discord?v=1",
      price:1
 },
    
 {
      name:"بروجكت قران",
      url:"https://replit.com/@ynllaamry/bwt-qrn-krym",
      price:1
 },
    
 {
      name:"بروجكت مسابقه صور",
      url:"https://replit.com/@OnlyMahmouud/bwt-msbqh-Swr",
      price:12000
 },
    
 {
      name:"بروجكت حمايه",
      url:"https://replit.com/@OnlyMahmouud/Powerful-Protection?v=1",
      price:7000
 },
    
 {
      name:"بروجكت تكت مطور",
      url:"https://cdn.discordapp.com/attachments/1218673575519715458/1218673625238995066/archive-2024-03-16T213219Z.tar.gz?ex=66618282&is=66603102&hm=d321b931c043a678712769711b27e4c385a04cbae3af3d81f04ff80175a019c1&",
      price:37500
 },
    
 {
      name:"بروجكت اراء",
      url:"https://cdn.discordapp.com/attachments/1246822990373716091/1246839376990703676/package.zip?ex=666124e8&is=665fd368&hm=b0f3d5f697fb50fd2365a2af6eb640da1dd88f38985fbd41c8ee475d0081cc55&",
      price:80000
 },
    
 {
      name:"بروجكت نداء",
      url:"https://replit.com/@NotNawaf/comebot",
      price:4000
 },
    
 {
      name:"بروجكت نقاط اداره",
      url:"https://replit.com/@leagimor/nqT-drh",
      price:3500
 },
    
 {
      name:"بروجكت خط",
      url:"https://cdn.discordapp.com/attachments/1218672441279123569/1218675379796181042/Autoliner.zip?ex=66618424&is=666032a4&hm=01d1a744c5c6733ba6a2eb24d8ff938b6ca53207842c4f6ebe7be0e885c31587&",
      price:4000
 },
    
 {
      name:"بروجكت زاجل",
      url:"https://replit.com/@NotYazan/Majhool",
      price:7500
 },
    
 {
      name:"بروجكت تشهير نصابين",
      url:"https://replit.com/@bn-lnSryhlnSry1/Mojtaba-scam-bot?v=1",
      price:4000
 },
    
 {
      name:"بروجكت بيع بروجكتات",
      url:"https://cdn.discordapp.com/attachments/1244757175276933151/1244792074797187183/ffgfdgfdgfhfghfhfghfghgfhgfhfghgfhgfhfgh-3.zip?ex=66619b35&is=666049b5&hm=dd9785549ccd1c95eb4c57a3f49e7cf31d32c8346271ab6fea062f21007113df&",
      price:17500
 },
    
 {
      name:"بروجكت بوت all in one",
      url:"https://replit.com/@bermoda55/Discord-Bot-All-In-One-V14?v=1",
      price:20000
 },
    
 {
      name:"بروجكت تشفير كلمات",
      url:"https://replit.com/@oolgmp/v13-3#index.js",
      price:6000
 },
 {
      name:"بروجكت لفلات",
      url:"https://cdn.discordapp.com/attachments/1229565096879980584/1247893801154904074/V13.zip?ex=6661af2a&is=66605daa&hm=9de5f2a13e8d46b37bdf51a446ac60fcfa5cadf0648822a2a017e7a980dd9c79&",
      price:100000
},
{
      name:"بروجكت تحذيرات بائعين",
      url:"https://cdn.discordapp.com/attachments/1174696897924046850/1247943931996667954/warn_bot.zip?ex=6661dddb&is=66608c5b&hm=4e262a7851ae20682399ede7d865ed0324a78c61549534772d046c657383f1a5&",
     price:50000
},
{
     name:"بروجكت اعطاء رولات تلقائي",
     url:"https://cdn.discordapp.com/attachments/1174696897924046850/1247944131913715852/Autorole_Bot.zip?ex=6661de0a&is=66608c8a&hm=c87077271822b30a23162caaa994b12a651f5dcf0ff97976233eca9a09b5c477&",
    price:55000
},
{
    name:"بروجكت تفعيل",
    url:"https://cdn.discordapp.com/attachments/1174696897924046850/1247944041325269123/verify_bot.zip?ex=6661ddf5&is=66608c75&hm=d52545ce6b14bb90977e2dae4ff41e8fc6e1443000f2fb7c2e7a67754e8ee190&",
    price:40000
},
{
    name:"بروجكت منع كلمات سيئه",
    url:"https://cdn.discordapp.com/attachments/1174696897924046850/1247953460570361957/bot_MAJED.zip?ex=6661e6ba&is=6660953a&hm=9e66ee7047cc4c8181988f347c4923cc214945afc66beff0dc646ed525b9019d&",
    price:37500
},   
  ]