const {
  Client,
  GatewayIntentBits,
  Partials,
  Collection,
} = require("discord.js");
var Discord = require("discord.js");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildPresences,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.DirectMessages,
    GatewayIntentBits.MessageContent,
  ],
  partials: [
    Partials.Channel,
    Partials.Message,
    Partials.User,
    Partials.GuildMember,
    Partials.Reaction,
  ],
});

const fs = require("fs");
client.config = require("./config.json");

const projects = require("./projects");
client.commands = new Collection();
client.aliases = new Collection();
client.slashCommands = new Collection();
client.buttons = new Collection();
client.prefix = client.config.prefix;
client.projects = projects;
const { Probot } = require("probot-transfer-uniqx"); // npm i discord-probot-transfer
/// Important !
client.probot = Probot(client, {
  fetchGuilds: true, // enable event for all bot guilds
  data: [
    {
      fetchMembers: true,
      guildId: client.config.serverid,
      probotId: client.config.probotid,
      owners: client.config.dev,
    },
  ],
});

module.exports = client;

fs.readdirSync("./handlers").forEach((handler) => {
  require(`./handlers/${handler}`)(client);
});
client.setMaxListeners(500);

client.login(client.config.token);

client.on("error", (err) => {
  console.log(err);
});

process.on("uncaughtException", (err) => {
  console.log(err);
});
process.on("uncaughtExceptionMonitor", (err) => {
  console.log(err);
});
process.on("rejectionHandled", (err) => {
  console.log(err);
});
