const {
    EmbedBuilder,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    Message,
    StringSelectMenuBuilder,
  } = require("discord.js");
  
  /**
   * @param {Message} message
   */
  module.exports = {
    name: "panel",
    description: "buy project form store",
    cooldown: 5000,
    userPerms: [],
    botPerms: ["SendMessages"],
    run: async (client, message, args) => {
   
   
     
      const embed = new EmbedBuilder()
        .setColor("Random")
        .setTimestamp()
        .setThumbnail(message.guild.iconURL())
        .setTitle("Buy Projects")
        .setDescription("**الرجاء الضغط على زر فتح تكت بالاسفل ل شراء البروجكتات**")
        //.setImage("")
        .setFooter({ text: message.guild.name, iconURL: message.guild.iconURL() })
        .setAuthor({
          name: message.guild.name,
          iconURL: message.guild.iconURL(),
        });
  
      
  
      const btn = new ButtonBuilder()
        .setStyle(ButtonStyle.Primary)
        .setLabel("Order !")
        .setCustomId(`order`)
        .setEmoji("🎟️");
  
  
    
      const row = new ActionRowBuilder().setComponents(btn);
  
      await message.channel.send({
        components: [row],
        embeds: [embed],
      });
  
      
    },
  };

  